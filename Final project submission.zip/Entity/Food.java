package Entity;

public class Food{
	
		private String foodCode;
		private String foodName;
		private String foodSize;
		private int foodPrice;
		
		public Food(){}
		public Food(String foodCode,String foodName,String foodSize,int foodPrice){
			this.foodCode=foodCode;
			this.foodName=foodName;
			this.foodSize=foodSize;				
			this.foodPrice=foodPrice;
		}
		
		public void setFoodName(String foodName){this.foodName=foodName;}
		public void setFoodCode(String foodCode){this.foodCode=foodCode;}
		public void setFoodSize(String foodSize){this.foodSize=foodSize;}
		public void setFoodPrice(int foodPrice){this.foodPrice=foodPrice;}
	
		
		public String getFoodName(){return this.foodName;}
		public String getFoodCode(){return this.foodCode;}
		public String getFoodSize(){return this.foodSize;}
		public int getFoodPrice(){return this.foodPrice;}
		
		public void showFoodInfo(){
			System.out.println("Food code : "+this.foodCode);
			System.out.println("Name : "+this.foodName);
			System.out.println("Size : "+this.foodSize);
			System.out.println("PRICE : "+this.foodPrice);
		}
		
		public String getFoodInfoAsString(){
		
		
		return 
		        "Code : "+foodCode+"\n"+
				" Name : "+foodName+"\n"+
				" Size : "+foodSize+"\n"+
				"Price : "+foodPrice+"\n";
				
	}
	
	
}