import java.lang.*;
import EntityList.*;
import Entity.*;
import Interfaces.*;
import File.*;

import GUI.*;
public class start{
	public static void main(String [] args){
		//AdminLogin al=new AdminLogin();
		//al.setVisible(true);
		
		//FoodMenu foodMenu = new FoodMenu(200);
	//FFileIO.loadFoodsFromFile(foodMenu);

    //FoodManage fm=new FoodManage(foodMenu);
	//Menu m = new Menu(foodMenu);
	//m.setVisible(true);
		
		/*forgotPassword fp = new forgotPassword(us);
		user u = new user("","","","","");
		updatePassword up = new updatePassword(u);
		up.setVisible(true);*/
		//user u = new user("","","","","");
		
		//user u ; // Instantiate a user object
		//user u = new user("","","","","");
        // users us = new users(); 
			//dashBoard db = new dashBoard( u, us);
					//db.setVisible(true);*/
		
	  Welcome w = new Welcome();
		w.setVisible(true);
		
		         // UserMenu um = new UserMenu(u,us);
			     // um.setVisible(true);
		
}}