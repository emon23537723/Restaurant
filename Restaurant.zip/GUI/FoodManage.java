package GUI;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import File.*;
import java.io.*;
import Entity.*;
import EntityList.*;
import File.FFileIO;


public class FoodManage extends JFrame implements ActionListener{
	Font titleFont = new Font("Algerian",Font.BOLD,30);
	Font titleLabel = new Font("Cambria",Font.BOLD,15);
	Font menuFont = new Font("Cambria",Font.BOLD,25);
	JTextField codeTextField,nameTextField,sizeTextField,priceTextField;
	JTextField searchTextField,deleteTextField;
	JButton addButton,updateButton,searchButton,deleteButton,clearButton,showAllButton,backButton,saveButton;
	JTextArea textArea;
	//FoodManage fm;
	 //AdminLogin al;
    FoodMenu foodMenu;
	
	public FoodManage(FoodMenu foodMenu){
		super("AIUB Kitchen");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(900,700); 
		this.setLocationRelativeTo(null); 
	
		this.setLayout(null);
	this.foodMenu = foodMenu;
		// Title
		
		JLabel title = new JLabel("AIUB Kitchen!");
		title.setBounds(250,15,400,50); 
		title.setFont(titleFont);
		
		// menu title
		
		JLabel subTitle = new JLabel("Menu");
		subTitle.setBounds(650,70,110,30); 
		subTitle.setFont(menuFont);
		
		
	
		//food code Entry 
		
		JLabel codeLabel = new JLabel("Food Code");
		codeLabel.setBounds(30,110,180,20); 
		codeLabel.setFont(titleLabel);
		
		codeTextField = new JTextField();
		codeTextField.setBounds(30,140,180,20); 
		codeTextField.setFont(titleLabel);
		
		
		JLabel nameLabel = new JLabel("Food Name");
		nameLabel.setBounds(30,170,180,20); 
		nameLabel.setFont(titleLabel);
		
		nameTextField = new JTextField();
		nameTextField.setBounds(30,200,180,20); 
		nameTextField.setFont(titleLabel);
		

		JLabel sizeLabel = new JLabel("Food Size");
	    sizeLabel.setBounds(30,230,180,20);
		sizeLabel.setFont(titleLabel);
		
		sizeTextField = new JTextField();
		sizeTextField.setBounds(30,260,180,20);
		sizeTextField.setFont(titleLabel);
		

		
		
		
		JLabel priceLabel = new JLabel("Food Price");
		priceLabel.setBounds(30,290,180,20); 
		priceLabel.setFont(titleLabel);
		
		priceTextField = new JTextField();
		priceTextField.setBounds(30,320,180,20);
		priceTextField.setFont(titleLabel);
		
	
		
		//Buttons
		
		
		addButton = new JButton("ADD");
		addButton.setBounds(30,360,180,20); 
		addButton.setBackground(Color.GREEN);
		addButton.setFont(titleLabel);
		addButton.addActionListener(this);
		
		
		updateButton = new JButton("UPDATE");
		updateButton.setBounds(30,390,180,20);
		updateButton.setBackground(Color.CYAN);
		updateButton.setForeground(Color.WHITE);
		updateButton.setFont(titleLabel);
		updateButton.addActionListener(this);
		

		
		
		//INFORMATION DISPLAY  AREA 
		textArea = new JTextArea();
		textArea.setBounds(480,120,400,450);
		textArea.setFont(titleLabel);
		textArea.setEditable(false);
		this.add(textArea);
 
	  reloadAllFoods();
	  FFileIO.loadFoodsFromFile(foodMenu);
	  
	JScrollPane jsp = new JScrollPane(textArea);
		jsp.setBounds(480,120,380,500);
		
		this.add(jsp);

	  
		
		
		
		//Search Entry
	
		JLabel searchLabel = new JLabel("Search By Food Code:");
		searchLabel.setBounds(260,110,200,20);
		searchLabel.setFont(titleLabel);
		
		searchTextField = new JTextField();
		searchTextField.setBounds(260,140,200,20);
		searchTextField.setFont(titleLabel);
		
		searchButton = new JButton("SEARCH");
		searchButton.setBounds(260,165,200,20);
		searchButton.setBackground(Color.YELLOW);
		searchButton.setFont(titleLabel);
		searchButton.addActionListener(this);
		
		
		
		//Delete Entry  
		
		JLabel deleteLabel = new JLabel("Delete By Food ID");
		deleteLabel.setBounds(260,200,200,20); 
		deleteLabel.setFont(titleLabel);
		
		deleteTextField = new JTextField();
		deleteTextField.setBounds(260,230,200,20);
		deleteTextField.setFont(titleLabel);
		
		deleteButton = new JButton("DELETE");
		deleteButton.setBounds(260,255,200,20);
		deleteButton.setBackground(Color.RED);
		deleteButton.setForeground(Color.WHITE);
		deleteButton.setFont(titleLabel);
		deleteButton.addActionListener(this);
		
		
		
		
		//Show All information
		
		showAllButton = new JButton("SHOW ALL Food");
		showAllButton.setBounds(260,300,200,20); //X,Y,W,H
		showAllButton.setBackground(Color.MAGENTA);
		showAllButton.setForeground(Color.WHITE);
		showAllButton.setFont(titleLabel);
		showAllButton.addActionListener(this);
		
		
		// Clear Screen 
		
		clearButton = new JButton("CLEAR SCREEN");
		clearButton.setBounds(260,330,200,20);
		clearButton.setBackground(Color.DARK_GRAY);
		clearButton.setForeground(Color.WHITE);
		clearButton.setFont(titleLabel);
		clearButton.addActionListener(this);
		
		
		backButton = new JButton("Back");
		backButton.setBounds(260,360,200,20);
		backButton.setBackground(Color.GRAY);
		backButton.setForeground(Color.WHITE);
		backButton.addActionListener(this);
		

		saveButton = new JButton("SAVE");
		saveButton.setBounds(260,390,200,20);
		saveButton.setBackground(Color.ORANGE);
		saveButton.setForeground(Color.WHITE);
		saveButton.addActionListener(this);
		
		
		
		
		this.add(title);
		this.add(subTitle);
		this.add(codeLabel);
		this.add(codeTextField);
		this.add(nameLabel);
		this.add(nameTextField);
		this.add(sizeLabel);
		this.add(sizeTextField);
	
		this.add(priceLabel);
		this.add(priceTextField);
		this.add(addButton);
		this.add(updateButton);
		this.add(searchLabel);
		this.add(searchTextField);
		this.add(searchButton);
		this.add(deleteLabel);
		this.add(deleteTextField);
		this.add(deleteButton);
		this.add(clearButton);
		this.add(showAllButton);
		this.add(backButton);
		this.add(saveButton);
		
		this.setVisible(true);
	}
	
	
	
	//@Override
	public void actionPerformed(ActionEvent ae){
		String command = ae.getActionCommand();
		

    if (addButton.getText().equals(command)) {
        System.out.println("ADD CLICKED");
		if(
				!codeTextField.getText().isEmpty() &&
				!nameTextField.getText().isEmpty() &&
				!sizeTextField.getText().isEmpty() &&
				!priceTextField.getText().isEmpty()
			){
			if( foodMenu.getByCode(codeTextField.getText()) == null){
				Food f = new Food(
							
							codeTextField.getText(),
							nameTextField.getText(),
							
							sizeTextField.getText(),
							
						    Integer.parseInt( priceTextField.getText())
						);
					
					foodMenu.insert(f);
					
					
					
					
					FFileIO.writeFoodInFile(f);
					
					
				
					
					reloadAllFoods();
			}
					
			else{
					JOptionPane.showMessageDialog(this,"This ID Already Exists","Provide Unique ID",JOptionPane.ERROR_MESSAGE);
				}
			}
        else{
				JOptionPane.showMessageDialog(this,"Please Provide all Information for ","Missing Information",JOptionPane.ERROR_MESSAGE);
			}
    }
	
	else if (updateButton.getText().equals(command)) {
      
        System.out.println("UPDATE CLICKED");
  			if(!codeTextField.getText().isEmpty() ){
				Food f = foodMenu.getByCode(codeTextField.getText());
				if(f!=null){
					if(!nameTextField.getText().isEmpty()){
						f.setFoodName(nameTextField.getText());
					}
					
					if(!sizeTextField.getText().isEmpty()){
						f.setFoodSize(sizeTextField.getText());
					}
					
					
					
					if(!priceTextField.getText().isEmpty()){
						f.setFoodPrice( Integer.parseInt( priceTextField.getText() ));
					}
					
					FFileIO.updateFoodsInFile(foodMenu);
					
					reloadAllFoods();
				}
				else{
					JOptionPane.showMessageDialog(this,"No Available Food ","Food Not Found",JOptionPane.ERROR_MESSAGE);
				}
			}
			else{
				JOptionPane.showMessageDialog(this,"Please Provide ID ","Missing Information",JOptionPane.ERROR_MESSAGE);
			}    
    }
	else if (searchButton.getText().equals(command)) {
    
        System.out.println("SEARCH CLICKED");
       Food f = foodMenu.getByCode(searchTextField.getText());
			if(f!=null){
				textArea.setText( f.getFoodInfoAsString() );
			}
			else{
				//textArea.setText( "NO BOOK FOUND" );
				JOptionPane.showMessageDialog(this,"NOT FOUND.","Alert",JOptionPane.WARNING_MESSAGE);
			}
    }
	else if (deleteButton.getText().equals(command)) {
       
        System.out.println("DELETE CLICKED");
     foodMenu.deleteByCode(deleteTextField.getText());
	 reloadAllFoods();
    }
	else if (showAllButton.getText().equals(command)) {
       
        System.out.println("SHOW ALL CLICKED");
      textArea.setText( foodMenu.getAll() );
	  reloadAllFoods();
    } 
	else if (clearButton.getText().equals(command)) {
       
        System.out.println("CLEAR CLICKED");
       textArea.setText("");
	   
    }
	else if(saveButton.getText().equals(command)){
		System.out.println("SAVE CLICKED");
			FFileIO.saveFoodsInFile(foodMenu);
		}
		else if(backButton.getText().equals(command)){
		System.exit(0);}
		
	
 } 
 	public void reloadAllFoods(){
		textArea.setText(foodMenu.getAll());
	}
}
		
		
		
		
	
	
